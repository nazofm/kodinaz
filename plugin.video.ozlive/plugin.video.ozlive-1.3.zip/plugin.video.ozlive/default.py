import sys
import xbmcgui
import xbmcplugin
import urllib
import urllib2
import re
import fileinput

 
addon_handle = int(sys.argv[1])
 
xbmcplugin.setContent(addon_handle, 'movies')


url = ''
li = xbmcgui.ListItem('[COLOR yellow]National[/COLOR]', iconImage='https://offshoregit.com/kjb/icons/ausmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://iphonestreaming.abc.net.au/news24/news24_hi.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('ABC News (24)', iconImage='https://offshoregit.com/kjb/icons/ABC%20News%2024.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'rtmp://118.97.183.196/jhos//aplus|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Australia Plus', iconImage='https://offshoregit.com/kjb/icons/Australia%20Plus.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://foxsportshlsg01-lh.akamaihd.net/i//fsnewshls_0@301672/master.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Fox Sports News', iconImage='https://offshoregit.com/kjb/icons/FoxSportsNews.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://melbourneseven-i.akamaihd.net/hls/live/263815-b/RAC/master_1000.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Racing.com', iconImage='https://offshoregit.com/kjb/icons/RacingAus.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = 'http://sbslivefvstreaming.sbs.com.au/out/u/sbs1-mo-000-c3093-delpkg1-delpkg1-abr/index-root-ipad.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('SBS One', iconImage='https://offshoregit.com/kjb/icons/SBS.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'http://sbslivefvstreaming.sbs.com.au/out/u/sbs2-mo-000-c3093-delpkg1-delpkg1-abr/index-root-ipad.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('SBS Viceland', iconImage='https://offshoregit.com/kjb/icons/SBS%20Viceland.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'http://sbslivefvstreaming.sbs.com.au/out/u/fdnet-mo-000-c3094-delpkg1-delpkg1-abr/index-root-ipad.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('SBS Food Network', iconImage='https://offshoregit.com/kjb/icons/SBS%20Food.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'http://sbslivefvstreaming.sbs.com.au/out/u/nitv-mo-000-c3094-delpkg1-delpkg1-abr/index-root-ipad.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('NITV', iconImage='https://offshoregit.com/kjb/icons/NITV.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = ''
li = xbmcgui.ListItem('[COLOR yellow]Perth[/COLOR]', iconImage='https://offshoregit.com/kjb/icons/ausmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://perthseven-i.akamaihd.net/hls/live/263674/PER1/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7', iconImage='https://offshoregit.com/kjb/icons/7.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://perthseven-i.akamaihd.net/hls/live/263675/PER2/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Two', iconImage='https://offshoregit.com/kjb/icons/7TWO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://perthseven-i.akamaihd.net/hls/live/263676/PER3/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Mate', iconImage='https://offshoregit.com/kjb/icons/7mate.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://perthseven-i.akamaihd.net/hls/live/263677/PER6/master_1000.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Flix', iconImage='https://offshoregit.com/kjb/icons/7flix.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://9nowch9livehls-i.akamaihd.net/hls/live/250963/perth/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9', iconImage='https://offshoregit.com/kjb/icons/9.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgemlivehls-i.akamaihd.net/hls/live/250973/perth/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Gem', iconImage='https://offshoregit.com/kjb/icons/9GEM.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgolivehls-i.akamaihd.net/hls/live/250978/perth/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Go', iconImage='https://offshoregit.com/kjb/icons/9GO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowlifelivehls-i.akamaihd.net/hls/live/250993/perth/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Life', iconImage='https://offshoregit.com/kjb/icons/9Life.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li) 

url = 'http://csm-e.cds1.yospace.com/csm/extlive/networkten01,SDNEW.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Ten (when live)', iconImage='https://offshoregit.com/kjb/icons/ten.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = ''
li = xbmcgui.ListItem('[COLOR yellow]Brisbane[/COLOR]', iconImage='https://offshoregit.com/kjb/icons/ausmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://brisbaneseven-i.akamaihd.net/hls/live/263663/BRI1/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7', iconImage='https://offshoregit.com/kjb/icons/7.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://brisbaneseven-i.akamaihd.net/hls/live/263664/BRI2/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Two', iconImage='https://offshoregit.com/kjb/icons/7TWO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://brisbaneseven-i.akamaihd.net/hls/live/263665/BRI3/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Mate', iconImage='https://offshoregit.com/kjb/icons/7mate.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://brisbaneseven-i.akamaihd.net/hls/live/263666-b/BRI6/master_1000.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Flix', iconImage='https://offshoregit.com/kjb/icons/7flix.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://9nowch9livehls-i.akamaihd.net/hls/live/250961/brisbane/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9', iconImage='https://offshoregit.com/kjb/icons/9.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgemlivehls-i.akamaihd.net/hls/live/250971/brisbane/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Gem', iconImage='https://offshoregit.com/kjb/icons/9GEM.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgolivehls-i.akamaihd.net/hls/live/250976/brisbane/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Go', iconImage='https://offshoregit.com/kjb/icons/9GO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowlifelivehls-i.akamaihd.net/hls/live/250991/brisbane/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Life', iconImage='https://offshoregit.com/kjb/icons/9Life.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li) 

url = 'http://csm-e.cds1.yospace.com/csm/extlive/networkten01,SDTVQ.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Ten (when live)', iconImage='https://offshoregit.com/kjb/icons/ten.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = ''
li = xbmcgui.ListItem('[COLOR yellow]Sydney[/COLOR]', iconImage='https://offshoregit.com/kjb/icons/ausmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://sydneyseven-i.akamaihd.net/hls/live/263630/SYD1/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7', iconImage='https://offshoregit.com/kjb/icons/7.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://sydneyseven-i.akamaihd.net/hls/live/263631/SYD2/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Two', iconImage='https://offshoregit.com/kjb/icons/7TWO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://sydneyseven-i.akamaihd.net/hls/live/263632/SYD3/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Mate', iconImage='https://offshoregit.com/kjb/icons/7mate.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://sydneyseven-i.akamaihd.net/hls/live/263634-b/SYD6/master_1000.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Flix', iconImage='https://offshoregit.com/kjb/icons/7flix.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://9nowch9livehls-i.akamaihd.net/hls/live/250964/sydney/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9', iconImage='https://offshoregit.com/kjb/icons/9.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgemlivehls-i.akamaihd.net/hls/live/250974/sydney/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Gem', iconImage='https://offshoregit.com/kjb/icons/9GEM.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgolivehls-i.akamaihd.net/hls/live/250987/sydney/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Go', iconImage='https://offshoregit.com/kjb/icons/9GO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowlifelivehls-i.akamaihd.net/hls/live/250994/sydney/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Life', iconImage='https://offshoregit.com/kjb/icons/9Life.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://csm-e.cds1.yospace.com/csm/extlive/networkten01,SDTEN.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Ten (when live)', iconImage='https://offshoregit.com/kjb/icons/ten.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = ''
li = xbmcgui.ListItem('[COLOR yellow]Melbourne [/COLOR]', iconImage='https://offshoregit.com/kjb/icons/ausmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://melbourneseven-i.akamaihd.net/hls/live/263658/MEL1/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7', iconImage='https://offshoregit.com/kjb/icons/7.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://melbourneseven-i.akamaihd.net/hls/live/263659/MEL2/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Two', iconImage='https://offshoregit.com/kjb/icons/7TWO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://melbourneseven-i.akamaihd.net/hls/live/263661/MEL3/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Mate', iconImage='https://offshoregit.com/kjb/icons/7mate.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://melbourneseven-i.akamaihd.net/hls/live/263662-b/MEL6/master_1000.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Flix', iconImage='https://offshoregit.com/kjb/icons/7flix.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://9nowch9livehls-i.akamaihd.net/hls/live/250962/melbourne/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9', iconImage='https://offshoregit.com/kjb/icons/9.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgemlivehls-i.akamaihd.net/hls/live/250972/melbourne/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Gem', iconImage='https://offshoregit.com/kjb/icons/9GEM.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgolivehls-i.akamaihd.net/hls/live/250977/melbourne/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Go', iconImage='https://offshoregit.com/kjb/icons/9GO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowlifelivehls-i.akamaihd.net/hls/live/250992/melbourne/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Life', iconImage='https://offshoregit.com/kjb/icons/9Life.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://csm-e.cds1.yospace.com/csm/extlive/networkten01,SDATV.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Ten (when live)', iconImage='https://offshoregit.com/kjb/icons/ten.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = ''
li = xbmcgui.ListItem('[COLOR yellow]Adelaide[/COLOR]', iconImage='https://offshoregit.com/kjb/icons/ausmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://adelaideseven-i.akamaihd.net/hls/live/263667/ADE1/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7', iconImage='https://offshoregit.com/kjb/icons/7.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://adelaideseven-i.akamaihd.net/hls/live/263668/ADE2/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Two', iconImage='https://offshoregit.com/kjb/icons/7TWO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://adelaideseven-i.akamaihd.net/hls/live/263669/ADE3/master_1500.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Mate', iconImage='https://offshoregit.com/kjb/icons/7mate.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://adelaideseven-i.akamaihd.net/hls/live/263670-b/ADE6/master_1000.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('7Flix', iconImage='https://offshoregit.com/kjb/icons/7flix.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'https://9nowch9livehls-i.akamaihd.net/hls/live/250960/adelaide/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9', iconImage='https://offshoregit.com/kjb/icons/9.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgemlivehls-i.akamaihd.net/hls/live/250970/adelaide/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Gem', iconImage='https://offshoregit.com/kjb/icons/9GEM.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowgolivehls-i.akamaihd.net/hls/live/250975/adelaide/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Go', iconImage='https://offshoregit.com/kjb/icons/9GO.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://9nowlifelivehls-i.akamaihd.net/hls/live/250990/adelaide/master1.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('9Life', iconImage='https://offshoregit.com/kjb/icons/9Life.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://csm-e.cds1.yospace.com/csm/extlive/networkten01,SDADS.m3u8|X-Forwarded-For=110.33.122.75'
li = xbmcgui.ListItem('Ten (when live)', iconImage='https://offshoregit.com/kjb/icons/ten.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = ''
li = xbmcgui.ListItem('[COLOR yellow]NZ Extras[/COLOR]', iconImage='https://offshoregit.com/kjb/icons/nzmap.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)


url = 'http://mworks-i.akamaihd.net/hls/live/247858/AES128/3812193411001/tv3_live/master_2000.m3u8|X-Forwarded-For=146.171.248.36'
li = xbmcgui.ListItem('Three', iconImage='https://offshoregit.com/kjb/icons/New%20Zealand%20-%20Three.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'http://mworks-i.akamaihd.net/hls/live/251979/AES128/3812193411001/Bravo_Live/master_1500.m3u8|X-Forwarded-For=146.171.248.36'
li = xbmcgui.ListItem('Bravo', iconImage='https://offshoregit.com/kjb/icons/New%20Zealand%20-%20Bravo.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'https://tvnzioslive01-i.akamaihd.net/hls/live/245926/tvnzhlsingest/Duke/playlistR_555.m3u8|X-Forwarded-For=146.171.248.36'
li = xbmcgui.ListItem('Duke', iconImage='https://offshoregit.com/kjb/icons/New%20Zealand%20-%20Duke.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
url = 'http://mediaworks-i.akamaihd.net/hls/live/220435/3812193411001/theedgetv_live/master_1500.m3u8|X-Forwarded-For=146.171.248.36'
li = xbmcgui.ListItem('The Edge', iconImage='https://offshoregit.com/kjb/icons/New%20Zealand%20-%20The%20Edge.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)		


xbmcplugin.endOfDirectory(addon_handle)
